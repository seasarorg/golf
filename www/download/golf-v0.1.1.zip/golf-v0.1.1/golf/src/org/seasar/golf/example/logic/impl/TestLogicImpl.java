/*
 * TestLogicImpl.java
 *
 * Created on 2006/12/24, 9:14
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.seasar.golf.example.logic.impl;

import org.seasar.golf.example.logic.TestLogic;

/**
 *
 * @author shimura
 */
public class TestLogicImpl implements TestLogic {
    
    /** Creates a new instance of TestLogicImpl */
    public TestLogicImpl() {
    }
    public String say() {
        return "OK";
    }
}
