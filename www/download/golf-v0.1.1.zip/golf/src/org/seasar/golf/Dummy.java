/*
 * Dummy.java
 *
 * Created on 2006/12/24, 9:57
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.seasar.golf;

/**
 *
 * @author shimura
 */
public class Dummy {
    
    /** Creates a new instance of Dummy */
    public Dummy() {
    }
    
}
