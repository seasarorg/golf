package org.seasar.golf.uexample.dao.exbhv;


/**
 * The behavior of company.
 * 
 * @author DBFlute(AutoGenerator)
 */
public class CompanyBhv extends org.seasar.golf.uexample.dao.bsbhv.BsCompanyBhv {
}
