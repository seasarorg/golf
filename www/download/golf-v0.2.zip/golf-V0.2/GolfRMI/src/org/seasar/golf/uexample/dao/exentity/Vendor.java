package org.seasar.golf.uexample.dao.exentity;


/**
 * The entity of vendor.
 * 
 * @author DBFlute(AutoGenerator)
 */
public class Vendor extends org.seasar.golf.uexample.dao.bsentity.BsVendor {

    /** Serial version UID. (Default) */
    private static final long serialVersionUID = 1L;
}
