package org.seasar.golf.uexample.dao.exentity;


/**
 * The entity of company.
 * 
 * @author DBFlute(AutoGenerator)
 */
public class Company extends org.seasar.golf.uexample.dao.bsentity.BsCompany {

    /** Serial version UID. (Default) */
    private static final long serialVersionUID = 1L;
}
