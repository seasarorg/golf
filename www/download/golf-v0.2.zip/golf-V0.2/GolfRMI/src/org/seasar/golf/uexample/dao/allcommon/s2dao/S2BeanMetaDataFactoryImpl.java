package org.seasar.golf.uexample.dao.allcommon.s2dao;

import org.seasar.dao.impl.BeanMetaDataFactoryImpl;

/**
 * BeanMetaDataFactoryImpl for DBFlute.
 * 
 * @author DBFlute(AutoGenerator)
 */
public class S2BeanMetaDataFactoryImpl extends BeanMetaDataFactoryImpl {
    protected int getLimitRelationNestLevel() {
        return 2;
    }
}