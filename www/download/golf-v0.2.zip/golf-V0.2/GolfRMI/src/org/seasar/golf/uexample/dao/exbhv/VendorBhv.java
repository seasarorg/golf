package org.seasar.golf.uexample.dao.exbhv;


/**
 * The behavior of vendor.
 * 
 * @author DBFlute(AutoGenerator)
 */
public class VendorBhv extends org.seasar.golf.uexample.dao.bsbhv.BsVendorBhv {
}
