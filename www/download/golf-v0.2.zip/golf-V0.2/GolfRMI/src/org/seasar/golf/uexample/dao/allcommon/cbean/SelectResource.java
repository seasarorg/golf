package org.seasar.golf.uexample.dao.allcommon.cbean;

/**
 * The select-resource as marker-interface.
 * 
 * @author DBFlute(AutoGenerator)
 */
public interface SelectResource {
}
