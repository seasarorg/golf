package org.seasar.golf.uexample.dao.cbean;


/**
 * The condition-bean of company.
 * 
 * @author DBFlute(AutoGenerator)
 */
public class CompanyCB extends org.seasar.golf.uexample.dao.cbean.bs.BsCompanyCB {
}
