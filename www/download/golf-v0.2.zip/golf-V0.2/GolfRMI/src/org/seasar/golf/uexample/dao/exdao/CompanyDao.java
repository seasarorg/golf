package org.seasar.golf.uexample.dao.exdao;


/**
 * The dao interface of company.
 * 
 * @author DBFlute(AutoGenerator)
 */
public interface CompanyDao extends org.seasar.golf.uexample.dao.bsdao.BsCompanyDao {
}
