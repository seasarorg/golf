package org.seasar.golf.uexample.dao.cbean;


/**
 * The condition-bean of vendor.
 * 
 * @author DBFlute(AutoGenerator)
 */
public class VendorCB extends org.seasar.golf.uexample.dao.cbean.bs.BsVendorCB {
}
