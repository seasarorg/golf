package org.seasar.golf.uexample.dao.exdao;


/**
 * The dao interface of vendor.
 * 
 * @author DBFlute(AutoGenerator)
 */
public interface VendorDao extends org.seasar.golf.uexample.dao.bsdao.BsVendorDao {
}
