/*
 * ValidationMessageLabel.java
 *
 * Created on 2007/01/03, 12:47
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.seasar.golf.util;

/**
 *
 * @author shimura
 */
public interface  ValidationMessageLabel {
    
    public String getMessageLabel(String label);
    
}
