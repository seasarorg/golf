/*
 * TestLogic.java
 *
 * Created on 2006/12/24, 9:15
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.seasar.golf.example.logic;

/**
 *
 * @author shimura
 */
public interface TestLogic {
    String say();
    
}
