/*
 * Copyright (c) 2003-2006 JGoodies Karsten Lentzsch. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of JGoodies Karsten Lentzsch nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */

package com.jgoodies.validation.tutorial.formatted.format;

import java.text.FieldPosition;
import java.text.Format;
import java.text.ParseException;
import java.text.ParsePosition;

/**
 * Wraps a given <code>Format</code> and adds behavior to convert to/from
 * the empty string. Therefore it holds an <em>empty value</em> that is
 * the counterpart of the empty string. The <code>#format</code> result 
 * of the empty value is the empty string, and the <code>#parse</code>
 * result of the empty string is the empty value. In all other cases
 * the formatting and parsing is forwarded to the wrapped Format.<p>
 * 
 * Often the empty value is <code>null</code>. For example you can wrap 
 * a <code>DateFormat</code> to format <code>null</code> to an empty string 
 * and parse the empty string to <code>null</code>. Another example is
 * the mapping of the <code>-1</code> to an empty string using a wrapped
 * <code>NumberFormat</code>. 
 * 
 * <strong>Examples:</strong><pre>
 * new EmptyFormat(new NumberFormat());
 * new EmptyFormat(new NumberFormat(), -1);
 * 
 * new EmptyFormat(DateFormat.getDateInstance());
 * new EmptyFormat(DateFormat.getDateInstance(DateFormat.SHORT));
 * </pre> 
 *
 * @author Karsten Lentzsch
 * @version $Revision: 1.6 $ 
 */
public final class EmptyFormat extends Format {
        
    /**
     * Refers to the wrapped Format that is used to forward 
     * <code>#format</code> and <code>#parseObject</code>. 
     */
    private final Format format;
    
    /**
     * Holds the object that represents the <em>empty</em> value.
     * The result of formatting this value is the empty string;
     * the result of parsing an empty string is this object.
     */
    private final Object emptyValue;
    
    
    // Instance Creation ****************************************************
    
    /**
     * Constructs an <code>EmptyFormat</code> that wraps the given format 
     * to convert <code>null</code> to the empty string and vice versa.
     * 
     * @param format  the format that handles the standard cases
     */
    public EmptyFormat(Format format) {
        this(format, null);
    }
    

    /**
     * Constructs an <code>EmptyFormat</code> that wraps the given format
     * to convert the given <code>emptyValue</code> to the empty string
     * and vice versa. 
     * 
     * @param format       the format that handles non-<code>null</code> values
     * @param emptyValue   the representation of the empty string
     */
    public EmptyFormat(Format format, Object emptyValue) {
        this.format     = format;
        this.emptyValue = emptyValue;
    }
    
    
    /**
     * Constructs an <code>EmptyFormat</code> that wraps the given format
     * to convert the given <code>emptyValue</code> to the empty string
     * and vice versa. 
     * 
     * @param format       the format that handles non-<code>null</code> values
     * @param emptyValue   the representation of the empty string
     */
    public EmptyFormat(Format format, int emptyValue) {
        this.format     = format;
        this.emptyValue = new Integer(emptyValue);
    }
    

    // Implementing Abstract Behavior ***************************************
        
    /**
     * Formats an object and appends the resulting text to a given string
     * buffer. If the <code>pos</code> argument identifies a field used by 
     * the format, then its indices are set to the beginning and end of 
     * the first such field encountered.
     *
     * @param obj    The object to format
     * @param toAppendTo    where the text is to be appended
     * @param pos    A <code>FieldPosition</code> identifying a field
     *               in the formatted text
     * @return       the string buffer passed in as <code>toAppendTo</code>,
     *               with formatted text appended
     * @exception NullPointerException if <code>toAppendTo</code> or
     *            <code>pos</code> is null
     * @exception IllegalArgumentException if the Format cannot format the given
     *            object
     */
    public StringBuffer format(Object obj, StringBuffer toAppendTo,
            FieldPosition pos) {
        return equals(obj, emptyValue)
                ? new StringBuffer()
                : format.format(obj, toAppendTo, pos);
    }


    /**
     * Parses text from the beginning of the given string to produce an object.
     * The method may not use the entire text of the given string.<p>
     * 
     * Unlike super this method returns the <code>emptyValue</code> if the 
     * source string is empty and does not throw a <code>ParseException</code>.
     *
     * @param source A <code>String</code> whose beginning should be parsed.
     * @return An <code>Object</code> parsed from the string.
     * @exception ParseException if the beginning of the specified string
     *            cannot be parsed.
     * @see java.text.Format#parseObject(java.lang.String)
     * @see javax.swing.JFormattedTextField#setValue(java.lang.Object)
     */
    public Object parseObject(String source) throws ParseException {
        return source.length() == 0
            ? emptyValue
            : super.parseObject(source);
    }

    
    /**
     * Parses text from a string to produce an object.<p>
     * 
     * The method attempts to parse text starting at the index given by
     * <code>pos</code>.
     * If parsing succeeds, then the index of <code>pos</code> is updated
     * to the index after the last character used (parsing does not necessarily
     * use all characters up to the end of the string), and the parsed
     * object is returned. The updated <code>pos</code> can be used to
     * indicate the starting point for the next call to this method.
     * If an error occurs, then the index of <code>pos</code> is not
     * changed, the error index of <code>pos</code> is set to the index of
     * the character where the error occurred, and null is returned.
     *
     * @param source A <code>String</code>, part of which should be parsed.
     * @param pos A <code>ParsePosition</code> object with index and error
     *            index information as described above.
     * @return An <code>Object</code> parsed from the string. In case of
     *         error, returns null.
     * @exception NullPointerException if <code>pos</code> is null.
     */
    public Object parseObject(String source, ParsePosition pos) {
        return format.parseObject(source, pos);
    }
    

    // Helper Code ************************************************************
    
    /**
     * Checks and answers if the two objects are both <code>null</code> or equal.
     * 
     * @param o1        the first object to compare
     * @param o2        the second object to compare
     * @return boolean  true iff both objects are <code>null</code> or equal
     */
    private boolean equals(Object o1, Object o2) {
        return    (o1 != null && o2 != null && o1.equals(o2))
                || (o1 == null && o2 == null);
    }
    
}
