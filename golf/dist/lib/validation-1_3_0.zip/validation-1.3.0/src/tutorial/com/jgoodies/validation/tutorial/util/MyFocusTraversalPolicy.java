/*
 * Copyright (c) 2003-2006 JGoodies Karsten Lentzsch. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of JGoodies Karsten Lentzsch nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */

package com.jgoodies.validation.tutorial.util;

import java.awt.Component;
import java.awt.FocusTraversalPolicy;

import javax.swing.JRootPane;
import javax.swing.JScrollBar;
import javax.swing.LayoutFocusTraversalPolicy;
import javax.swing.text.JTextComponent;

/**
 * A FocusTraversalPolicy that determines traversal order based on the order
 * of child Components in a Container. In addition to its superclass,
 * this class excludes non-editable text components, scroll bars, and the
 * root pane from the focus cycle. The JGoodies User Interface Framework (UIF)
 * contains an extended version of this policy.
 *
 * @author Karsten Lentzsch
 * @version $Revision: 1.5 $
 * @since 1.4
 *
 * @see JTextComponent#isEditable()
 */
public final class MyFocusTraversalPolicy extends LayoutFocusTraversalPolicy {
        
    /**
     * Holds the single instance of this focus traversal policy.
     * 
     * @see java.awt.KeyboardFocusManager#setDefaultFocusTraversalPolicy(java.awt.FocusTraversalPolicy)
     */
    public static final FocusTraversalPolicy INSTANCE 
        = new MyFocusTraversalPolicy();


    
    // Instance Creation ******************************************************
    
    /**
     * Constructs a UIFFocusTraversalPolicy with no initial component set.
     */
    private MyFocusTraversalPolicy() {
         // Overrides default constructor; ensuring non-instantiability.
    }
    
    
    // ************************************************************************
    
    /**
     * Determines whether a Component is an acceptable choice as the new
     * focus owner. By default, this method will accept a Component if and
     * only if it is visible, displayable, enabled, and focusable, 
     * no JScrollBar, no JRootPane, and in case of a JTextComponent, 
     * it must be editable.
     * 
     * @param aComponent the Component whose fitness as a focus owner is to
     *        be tested
     * @return <code>true</code> if aComponent is visible, displayable,
     *         enabled, and focusable; <code>false</code> otherwise
     */
    protected boolean accept(Component aComponent) {
        if (!super.accept(aComponent)) {
            return false;
        } else if (aComponent instanceof JTextComponent) {
            JTextComponent textComponent = (JTextComponent) aComponent;
            return textComponent.isEditable();
        } else if (aComponent instanceof JScrollBar) {
            return false;
        } else if (aComponent instanceof JRootPane) {
            return false;
        } else {
            return true;
        }
    }
    
        
}
