/*
 * Copyright (c) 2003-2006 JGoodies Karsten Lentzsch. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of JGoodies Karsten Lentzsch nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */

package com.jgoodies.validation.tutorial.formatted.formatter;

import java.text.NumberFormat;
import java.text.ParseException;

import javax.swing.text.NumberFormatter;

/**
 * Unlike its superclass <code>NumberFormatter</code>, this class
 * converts non-negative integers to natural language strings:
 * Zero, One, Two, Three, More than three.
 * 
 * @author  Karsten Lentzsch
 * @version $Revision: 1.5 $
 * 
 * @see javax.swing.JFormattedTextField
 */
public final class CustomNumberFormatter extends NumberFormatter {
    
    // Instance Creation ****************************************************

    /**
     * Constructs a <code>CustomNumberFormatter</code>.
     */
    public CustomNumberFormatter() {
        // Implicitly invoke the super constructor.
    }

    /**
     * Constructs a <code>CustomNumberFormatter</code> using the given
     * <code>NumberFormat</code> to convert strings to values.
     * 
     * @param numberFormat   the NumberFormat used to parse numbers
     */
    public CustomNumberFormatter(NumberFormat numberFormat) {
        super(numberFormat);
    }

    
    // Overriding Superclass Behavior ****************************************

    /**
     * Returns a String representation of the Object <code>value</code>.
     * This invokes <code>format</code> on the current <code>Format</code>.<p>
     * 
     * In addition to the superclass behavior, this method formats the numbers 
     * for zero, one, two, three and fourty-two to the natural language strings.
     *
     * @param value Value to convert
     * @return String representation of value
     * @throws ParseException if there is an error in the conversion
     */
    public String valueToString(Object value) throws ParseException {
        if (value == null || !(value instanceof Number))
            return super.valueToString(value);
        
        Number number = (Number) value;
        int intValue = number.intValue();
        if (intValue < 0) {
            return "Negative";
        } else if (intValue == 0) {
            return "Zero";
        } else if (intValue == 1) {
            return "One";
        } else if (intValue == 2) {
            return "Two";
        } else if (intValue == 3) {
            return "Three";
        } else if (intValue > 3) {
            return "More than 3";
        } else
            return super.valueToString(value);
    }

    
}
