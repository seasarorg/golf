/*
 * Copyright (c) 2003-2006 JGoodies Karsten Lentzsch. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of JGoodies Karsten Lentzsch nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */

package com.jgoodies.validation.tutorial.formatted.format;

import java.text.*;
import java.util.Date;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import com.jgoodies.validation.util.ValidationUtils;

/**
 * A <code>Format</code> that provides special handling for output
 * shortcuts and relative input.<p>
 * 
 * If output shortcuts are enabled, Yesterday, Today and Tomorrow 
 * are formatted using their localized human-language print strings.<p>
 * 
 * If relative input is allowed, the parser accepts signed integers 
 * that encode a date relative to today; this input would otherwise
 * be considered invalid.<p>
 * 
 * This class is intended for demonstration purposes only. It is superceded by 
 * the {@link com.jgoodies.validation.formatter.RelativeDateFormatter}.
 * 
 * @author  Karsten Lentzsch
 * @version $Revision: 1.7 $
 * 
 * @see com.jgoodies.validation.util.ValidationUtils
 */
public final class RelativeDateFormat extends DateFormat {
    
    // Keys and Value for the Shortcut Localization ***************************
    
    /**
     * The resource key used to lookup the localized text for "Yesterday".
     */
    public static final String KEY_YESTERDAY = "RelativeDate.yesterday";

    /**
     * The resource key used to lookup the localized text for "Today".
     */
    public static final String KEY_TODAY     = "RelativeDate.today";

    /**
     * The resource key used to lookup the localized text for "Tomorrow".
     */
    public static final String KEY_TOMORROW  = "RelativeDate.tomorrow";

    private static final String VALUE_YESTERDAY = "Yesterday";
    private static final String VALUE_TODAY     = "Today";
    private static final String VALUE_TOMORROW  = "Tomorrow";
    

    // ************************************************************************
    
    private static final NumberFormat INTEGER_FORMAT =
        NumberFormat.getIntegerInstance();

    private final DateFormat delegate;
    private final boolean useOutputShortcuts;
    private final boolean allowRelativeInput;
    
    /**
     * Refers to an optional ResourceBundle that is used to localize 
     * the texts for the output shortcuts: Yesterday, Today, Tomorrow.
     */
    private ResourceBundle resourceBundle;
    

    // Instance Creation ****************************************************

    /**
     * Constructs a wrapped format that provides special handling 
     * for output shortcuts and relative input.
     */
    public RelativeDateFormat() {
        this(DateFormat.getDateInstance(), true, true);
    }

    /**
     * Constructs a wrapped format that provides special handling 
     * for output shortcuts and relative input.
     * 
     * @param delegate   the DateFormat to handle format and parse dates
     * @param useOutputShortcuts  true indicates that dates are formatted
     *   with shortcuts for yesterday, today, and tomorrow, where false 
     *   always converts using absolute numbers for day, month and year.
     * @param allowRelativeInput  true indicates that the parser accepts
     *   signed integers that encode a date relative to today; if false
     *   such input is considered invalid
     */
    public RelativeDateFormat(
        DateFormat delegate,
        boolean useOutputShortcuts,
        boolean allowRelativeInput) {
        this.delegate = delegate;
        this.useOutputShortcuts = useOutputShortcuts;
        this.allowRelativeInput = allowRelativeInput;
    }

    // Factory Methods ******************************************************

    /**
     * Creates and answers the default <code>Format</code> that is used 
     * to edit instances of {@link Date} in the UI: 
     * It converts <code>null</code> to empty Strings, 
     * uses the short <code>DateFormat</code>, 
     * uses shortcuts for output and 
     * accepts relative input.
     * 
     * @return the default date format that converts Dates to Strings
     */
    public static Format getDefaultEditDateFormat() {
        return createDateFormat(DateFormat.MEDIUM, true, true);
    }

    /**
     * Creates and answers the default <code>Format</code> that is used 
     * to edit instances of {@link Date} in the UI: 
     * It converts <code>null</code> to empty Strings, 
     * uses the short <code>DateFormat</code>, 
     * uses shortcuts for output and 
     * does not accepts relative input.
     * 
     * @return the default date format that converts Dates to Strings
     */
    public static Format getDefaultDisplayDateFormat() {
        return createDateFormat(DateFormat.MEDIUM, true, false);
    }

    /**
     * Creates and answers the default <code>Format</code> that is used 
     * to edit instances of {@link Date} in the UI: 
     * It converts <code>null</code> to empty Strings, 
     * uses the short <code>DateFormat</code>, 
     * does not uses shortcuts for output and 
     * does not accepts relative input.
     * 
     * @return the default date format that converts Dates to Strings
     */
    public static Format getDefaultPrintDateFormat() {
        return createDateFormat(DateFormat.SHORT, false, false);
    }

    /**
     * Creates and returns a <code>Format</code> that converts 
     * Dates to Strings and vice versa. The format uses the specified 
     * {@link DateFormat} style and can be configured via the parameters.
     * 
     * Also, the editable format allows to enter shortcuts for 
     * <p>
     * Printable indicates that dates must always be converted 
     * using absolute numbers, where displayed dates will use shortcuts
     * for yesterday, today and tomorrow.
     * 
     * @param style               the <code>DateFormat</code> style for 
     *   short, medium and long output and input format
     * @param useOutputShortcuts  true indicates that dates are formatted
     *   with shortcuts for yesterday, today, and tomorrow, where false 
     *   always converts using absolute numbers for day, month and year.
     * @param allowRelativeInput  true indicates that the parser accepts
     *   signed integers that encode a date relative to today; if false
     *   such input is considered invalid
     * @return a date format that converts Dates to Strings
     */
    private static Format createDateFormat(
        int style,
        boolean useOutputShortcuts,
        boolean allowRelativeInput) {
        return new EmptyFormat(
            new RelativeDateFormat(
                DateFormat.getDateInstance(style),
                useOutputShortcuts,
                allowRelativeInput));
    }

    // Implementing Abstract Behavior ***************************************

    /**
     * Formats a Date into a date/time string.
     * In addition to the delegate's behavior, this method formats 
     * the dates for yesterday, today and tomorrow to the natural
     * language strings.
     * 
     * @param date a Date to be formatted into a date/time string.
     * @param toAppendTo the string buffer for the returning date/time string.
     * @param fieldPosition keeps track of the position of the field
     * within the returned string.
     * On input: an alignment field,
     * if desired. On output: the offsets of the alignment field. For
     * example, given a time text "1996.07.10 AD at 15:08:56 PDT",
     * if the given fieldPosition is DateFormat.YEAR_FIELD, the
     * begin index and end index of fieldPosition will be set to
     * 0 and 4, respectively.
     * Notice that if the same time field appears
     * more than once in a pattern, the fieldPosition will be set for the first
     * occurrence of that time field. For instance, formatting a Date to
     * the time string "1 PM PDT (Pacific Daylight Time)" using the pattern
     * "h a z (zzzz)" and the alignment field DateFormat.TIMEZONE_FIELD,
     * the begin index and end index of fieldPosition will be set to
     * 5 and 8, respectively, for the first occurrence of the timezone
     * pattern character 'z'.
     * @return the formatted date/time string.
     */
    public StringBuffer format(
        Date date,
        StringBuffer toAppendTo,
        FieldPosition fieldPosition) {
        if (date == null)
            return new StringBuffer();
        else if (useOutputShortcuts && ValidationUtils.isYesterday(date)) {
            return new StringBuffer(getString(KEY_YESTERDAY, VALUE_YESTERDAY));
        } else if (useOutputShortcuts && ValidationUtils.isToday(date)) {
            return new StringBuffer(getString(KEY_TODAY, VALUE_TODAY));
        } else if (useOutputShortcuts && ValidationUtils.isTomorrow(date)) {
            return new StringBuffer(getString(KEY_TOMORROW, VALUE_TOMORROW));
        }
        return delegate.format(date, toAppendTo, fieldPosition);
    }

    /**
     * Parse a date/time string according to the given parse position.  For
     * example, a time text "07/10/96 4:5 PM, PDT" will be parsed into a Date
     * that is equivalent to Date(837039928046).
     * <p> 
     * By default, parsing is lenient: If the input is not in the form used
     * by this object's format method but can still be parsed as a date, then
     * the parse succeeds.  Clients may insist on strict adherence to the
     * format by calling setLenient(false).
     * <p>
     * In addition to the delegate's behavior, this methods accepts
     * signed integers interpreted as days relative to today.
     *
     * @see java.text.DateFormat#setLenient(boolean)
     *
     * @param source  The date/time string to be parsed
     *
     * @param pos   On input, the position at which to start parsing; on
     *              output, the position at which parsing terminated, or the
     *              start position if the parse failed.
     *
     * @return      A Date, or null if the input could not be parsed
     */
    public Date parse(String source, ParsePosition pos) {
        int storedIndex = pos.getIndex();

        Date date = delegate.parse(source, pos);
        if (date != null || !allowRelativeInput) {
            return date;
        }

        // We failed to parse a date; try a relative date now.

        // Reset the parse position.
        pos.setIndex(storedIndex);
        Number offsetDays = INTEGER_FORMAT.parse(source, pos);
        if (offsetDays == null) {
            // Even this failed.
            return null;
        }

        return ValidationUtils.getRelativeDate(offsetDays.intValue());
    }
    
    
    // Internationalization **************************************************
    
    public ResourceBundle getResourceBundle() {
        return resourceBundle;
    }
    
    public void setResourceBundle(ResourceBundle newBundle) {
        resourceBundle = newBundle;
    }
    
    /**
     * Retrieves and returns a <code>String</code> for the given key from the
     * a resource bundle. This implementation refers to the bundle that
     * is provided by the UIF's <code>ResourceManager</code>.
     * 
     * @param key           the key used to lookup the localized string
     * @param defaultText   a fallback text if the resource is missing
     * @return the localized text or default text
     */
    private String getString(String key, String defaultText) {
        ResourceBundle bundle = getResourceBundle();
        if (bundle == null)
            return defaultText;
            
        try {
            return bundle.getString(key);
        } catch (MissingResourceException e) {
            return defaultText;
        }
    }
    
    
    

}
