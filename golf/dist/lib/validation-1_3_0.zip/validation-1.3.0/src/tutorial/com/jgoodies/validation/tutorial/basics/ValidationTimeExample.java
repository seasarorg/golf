/*
 * Copyright (c) 2003-2006 JGoodies Karsten Lentzsch. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 * 
 *  o Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer. 
 *     
 *  o Redistributions in binary form must reproduce the above copyright notice, 
 *    this list of conditions and the following disclaimer in the documentation 
 *    and/or other materials provided with the distribution. 
 *     
 *  o Neither the name of JGoodies Karsten Lentzsch nor the names of 
 *    its contributors may be used to endorse or promote products derived 
 *    from this software without specific prior written permission. 
 *     
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
 */

package com.jgoodies.validation.tutorial.basics;

import java.awt.event.ActionEvent;

import javax.swing.*;

import com.jgoodies.binding.PresentationModel;
import com.jgoodies.forms.builder.PanelBuilder;
import com.jgoodies.forms.factories.ButtonBarFactory;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.validation.ValidationResult;
import com.jgoodies.validation.ValidationResultModel;
import com.jgoodies.validation.tutorial.shared.Order;
import com.jgoodies.validation.tutorial.shared.OrderModel;
import com.jgoodies.validation.tutorial.util.ExampleComponentFactory;
import com.jgoodies.validation.tutorial.util.TutorialUtils;
import com.jgoodies.validation.tutorial.validator.OrderValidator;
import com.jgoodies.validation.util.DefaultValidationResultModel;
import com.jgoodies.validation.view.ValidationResultViewFactory;

/**
 * Demonstrates and compares different validation times: 
 * key-typed, focus lost, commit (OK pressed). 
 * 
 * @author  Karsten Lentzsch
 * @version $Revision: 1.8 $
 */

public final class ValidationTimeExample {
    
    private OrderModel keyTypedModel;
    private JTextField keyTypedOrderNoField;
    private JTextField keyTypedOrderDateField;
    private JComponent keyTypedResultView;
    
    private OrderModel focusLostModel;
    private JTextField focusLostOrderNoField;
    private JTextField focusLostOrderDateField;
    private JComponent focusLostResultView;
    
    private CommitOrderModel commitModel;
    private JTextField commitOrderNoField;
    private JTextField commitOrderDateField;
    private JComponent commitResultView;
    private JButton    commitOKButton;
    private JButton    commitCancelButton;
    

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel("com.jgoodies.looks.plastic.PlasticXPLookAndFeel");
        } catch (Exception e) {
            // Likely Plastic is not in the classpath; ignore it.
        }
        JFrame frame = new JFrame();
        frame.setTitle("Basics :: Validation Time");
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        JComponent panel = new ValidationTimeExample().buildPanel();
        frame.getContentPane().add(panel);
        frame.pack();
        TutorialUtils.locateOnScreenCenter(frame);
        frame.setVisible(true);
    }

    
    // Instance Creation ******************************************************

    public ValidationTimeExample() {
        keyTypedModel  = new OrderModel(new Order());
        focusLostModel = new OrderModel(new Order());
        commitModel    = new CommitOrderModel(new Order());
    }
    
    
    // Component Creation and Initialization **********************************

    private void initComponents() {
        // To commit on key typed we invoke #createTextField
        // with the optional boolean parameter set to false.
        keyTypedOrderNoField = ExampleComponentFactory.createTextField(
                keyTypedModel.getModel(Order.PROPERTYNAME_ORDER_NO), 
                false);
        // We can't commit Dates on key typed, only on valid edit.
        keyTypedOrderDateField = ExampleComponentFactory.createDateField(
                keyTypedModel.getModel(Order.PROPERTYNAME_ORDER_DATE), 
                true,
                true);
        keyTypedResultView = ValidationResultViewFactory.createReportIconAndTextPane(
                keyTypedModel.getValidationResultModel());

        // By default #createTextField commits on focus lost
        focusLostOrderNoField = ExampleComponentFactory.createTextField(
                focusLostModel.getModel(Order.PROPERTYNAME_ORDER_NO));
        focusLostOrderDateField = ExampleComponentFactory.createDateField(
                focusLostModel.getModel(Order.PROPERTYNAME_ORDER_DATE));
        focusLostResultView = ValidationResultViewFactory.createReportIconAndTextPane(
                focusLostModel.getValidationResultModel());

        // Here we delay commits by using the Binding buffering support.
        commitOrderNoField = ExampleComponentFactory.createTextField(
                commitModel.getBufferedModel(Order.PROPERTYNAME_ORDER_NO));
        commitOrderDateField = ExampleComponentFactory.createDateField(
                commitModel.getBufferedModel(Order.PROPERTYNAME_ORDER_DATE));
        commitResultView = ValidationResultViewFactory.createReportIconAndTextPane(
                commitModel.getValidationResultModel());
        commitOKButton = new JButton(commitModel.getOKAction());
        commitCancelButton = new JButton(commitModel.getCancelAction());
    }
    
    
    // Building ***************************************************************

    /**
     * Builds and returns the whole editor with 3 sections 
     * for the different validation times.
     */
    public JComponent buildPanel() {
        initComponents();
        
        FormLayout layout = new FormLayout(
                "fill:pref:grow",
                "p, 3dlu, p, 6dlu, p, 3dlu, p, 6dlu, p, 3dlu, p");
        
        PanelBuilder builder = new PanelBuilder(layout);
        builder.setDefaultDialogBorder();
        CellConstraints cc = new CellConstraints();
        
        builder.addSeparator("Validate on Key Typed",   cc.xy(1,  1));
        builder.add(buildKeyTypedPanel(),               cc.xy(1,  3));
        builder.addSeparator("Validate on Focus Lost",  cc.xy(1,  5));
        builder.add(buildFocusLostPanel(),              cc.xy(1,  7));
        builder.addSeparator("Validate on Commit (OK)", cc.xy(1,  9));
        builder.add(buildCommitPanel(),                 cc.xy(1, 11));
        return builder.getPanel();
    }
    
    
    private JComponent buildKeyTypedPanel() {
        FormLayout layout = new FormLayout(
                "right:max(65dlu;pref), 4dlu, 40dlu, 2dlu, 40dlu, 80dlu:grow",
                "p, 3dlu, p, 9dlu, fill:max(22dlu;p)");
        
        PanelBuilder builder = new PanelBuilder(layout);
        CellConstraints cc = new CellConstraints();
        
        builder.addLabel("Order No",         cc.xy (1, 1));
        builder.add(keyTypedOrderNoField,    cc.xyw(3, 1, 3));
        builder.addLabel("Order Date",       cc.xy (1, 3));
        builder.add(keyTypedOrderDateField,  cc.xy (3, 3));
        builder.addLabel("(commits on valid edit)", cc.xyw(5, 3, 2));
        builder.add(keyTypedResultView,      cc.xyw(3, 5, 4));
        return builder.getPanel();
    }
    
    
    private JComponent buildFocusLostPanel() {
        FormLayout layout = new FormLayout(
                "right:max(65dlu;pref), 4dlu, 40dlu, 2dlu, 40dlu, 80dlu:grow",
                "p, 3dlu, p, 9dlu, fill:max(22dlu;p)");
        
        PanelBuilder builder = new PanelBuilder(layout);
        CellConstraints cc = new CellConstraints();
        
        builder.addLabel("Order No",         cc.xy (1, 1));
        builder.add(focusLostOrderNoField,   cc.xyw(3, 1, 3));
        builder.addLabel("Order Date",       cc.xy (1, 3));
        builder.add(focusLostOrderDateField, cc.xy (3, 3));
        builder.add(focusLostResultView,     cc.xyw(3, 5, 4));
        return builder.getPanel();
    }
    
    
    private JComponent buildCommitPanel() {
        FormLayout layout = new FormLayout(
                "right:max(65dlu;pref), 4dlu, 40dlu, 2dlu, 40dlu, 80dlu:grow",
                "p, 3dlu, p, 9dlu, fill:max(22dlu;p), 2dlu:grow, p");
        
        PanelBuilder builder = new PanelBuilder(layout);
        CellConstraints cc = new CellConstraints();
        
        builder.addLabel("Order No",         cc.xy (1, 1));
        builder.add(commitOrderNoField,      cc.xyw(3, 1, 3));
        builder.addLabel("Order Date",       cc.xy (1, 3));
        builder.add(commitOrderDateField,    cc.xy (3, 3));
        builder.add(commitResultView,        cc.xyw(3, 5, 4));
        builder.add(buildCommitButtonBar(),  cc.xyw(3, 7, 4));
        return builder.getPanel();
    }
    
    private JComponent buildCommitButtonBar() {
        return ButtonBarFactory.buildRightAlignedBar(
                commitOKButton, commitCancelButton);
    }

    
    // Domain Classes *********************************************************
    
    /**
     * Provides the validation result model and actions necessary to 
     * build a presentation.
     */
    private static final class CommitOrderModel extends PresentationModel {
        
        private final ValidationResultModel validationResultModel;
        private final Action okAction;
        private final Action cancelAction;
        
        // Instance Creation -------------------------------------
        
        CommitOrderModel(Order order) {
            super(order);
            validationResultModel = new DefaultValidationResultModel();
            okAction = new OKAction();
            cancelAction = new CancelAction();
        }
        
        
        // Exposing Models -------------------------------------------
        
        ValidationResultModel getValidationResultModel() {
            return validationResultModel;
        }
        
        Action getOKAction() {
            return okAction;
        }
        
        Action getCancelAction() {
            return cancelAction;
        }
        
        
        // Validation ------------------------------------------------
        
        
        private void updateValidationResult() {
            Order order = (Order) getBean();
            ValidationResult result = new OrderValidator(order).validate();
            validationResultModel.setResult(result);
        }
        
        
        // -------------------------------------------------------
        
        /**
         * Commits buffered changes and updates the validation result.
         */
        private final class OKAction extends AbstractAction {
            
            private OKAction() { super("OK"); }
            
            public void actionPerformed(ActionEvent evt) {
                triggerCommit();
                updateValidationResult();
            }
        }
        
        
        /**
         * Flushes buffered changes and updates the validation result.
         */
        private final class CancelAction extends AbstractAction {
            
            private CancelAction() { super("Cancel"); }
            
            public void actionPerformed(ActionEvent evt) {
                triggerFlush();
                updateValidationResult();
            }
        }
        
    }
    
    
}
